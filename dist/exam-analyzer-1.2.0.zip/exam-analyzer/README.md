# 试卷解析镜（Exam lens）

在 DSH Web 界面里打开一份 PDF 试卷的**原始版面**，用鼠标框选任意一道题，
右侧立刻给出：**答案 → 涉及的知识点 → 可迁移/易混知识点 → 分步解析 → 3 道相似题（含完整选项与答案）**。

支持扫描件、文字版/矢量 PDF、图文混排；根号有上横线，分数上下堆叠。

---

## 安装（分享给别人时这样做）

插件是**零运行时依赖**的自包含包（pdf.js 已随包内置在 `vendor/`），不需要联网装依赖。

### 方式一：用打好的 tgz（推荐）

1. 把 `exam-analyzer-1.2.0.tgz` 放到任意目录，例如 `D:\plugins\`；
2. 在 DSH 里让 Agent 执行：

   ```
   plugin_manager  action=install_bundle  target=D:\plugins\exam-analyzer-1.2.0.tgz
   ```

   （或解压后用 `target=<解压出来的目录>`）

3. 安装完成后**刷新一次页面**（Ctrl+R），页面右下角出现「📄 试卷解析」。

### 方式二：用 zip 文件夹

1. 解压 `exam-analyzer-1.2.0.zip`，得到 `exam-analyzer/` 目录；
2. `plugin_manager action=install_bundle target=<该目录的绝对路径>`；
3. 刷新页面。

### 方式三：手动放置

把整个目录放到 DSH 的插件目录，并在 profile 的 `cordis.patch.yml` 里插入：

```yaml
- insert:
    - id: exam-analyzer
      name: '@local/exam-analyzer'
      config: {}
```

然后重启 DSH。

### 环境要求

- DSH 具备 `shell.overlay` 槽、`attachments` 与 `llm` 服务（0.2 及以上桌面版满足）；
- 当前会话模型需要**支持图片输入**（如 `deepseek-flash`，可用 `GET /api/exam-analyzer/model` 查看 `inputModalities`）。

---

## 使用

1. 点右下角「📄 试卷解析」→ 选择 PDF（也可直接把文件拖进面板）；
2. 左侧显示**试卷原图**，可翻页、适应宽度/放大；滚动到要做的题；
3. 在题目上按住鼠标拖框（把题干和选项都框进去）；
4. 选区留在卷面上（蓝色方框），右侧给出解析；可「复制解析」「重新识别」「清除选区」。

### 面板可调整大小

- 拖面板**左边缘**改宽度、拖**下边缘**改高度，尺寸记在 localStorage，下次打开保持；
- 头部「最大化 / 还原」一键铺满。

### 一键全卷答案

- 头部「全部答案」：逐页识别整页题目，右侧按「第 n 页」列出 **题号 + 答案 + 题干摘要**，
  显示「已识别 k 页 · m 题」，支持「复制全卷答案 / 返回单题解析 / 重新识别」；
- **整页识别使用 2200 px 高清重渲染（JPEG）**，比浏览用的 1400 px 预览清晰得多，密集文字页效果更好；
- 每页一次模型调用（约 10-15 秒/页），带进度提示，单页失败不影响其它页；
- 图形/装置题仍建议**单题框选**：整页缩略后小图容易误判。

### 分段精解（推荐用于图形题多的卷子）

- 头部「分段精解」：先按**页面空白带**把每页切成 2–3 段（墨迹投影找空白行，不依赖模型给坐标），
  再把每段以 2200 px 送去识别，段内题目由模型逐条列出，按「页码-题号」去重合并；
- 相比整页模式，每段图更大、题更少，装置图/表格题明显更准；相比单题框选，不用一题一拖；
- 代价是调用次数多（4 页约 12 段 ≈ 2 分钟），进度里会显示「第 x/y 页 · 第 k/n 段」。

### 学科识别

解析栏标题旁会显示模型判断出的学科标签（数学 / 物理 / 化学），提示词已改为「初中理科」，
化学题会要求配平、标条件、化学式用下标，不再因为“不是数学题”而拒绝作答。

### 本地题库

- 解析完一道题，在「识别到的题目」下方选学科（默认用模型判断的学科）→「存入题库」；
- **只存题目里的图形，不存整块截图**：保存时先让模型判断图形在图中的方位（上/下/左/右/整图），
  再按比例把那一块裁出来，最多存 3 张图；题干本身以文字入库，不再重复占空间；
- 纯文字题（模型判定无图形）不会存图，提示「此题无图形」；
- 头部「题库 N」打开题库：按学科筛选、关键词搜索（题目/答案/知识点）、缩略图点击放大、逐条删除；
- 存储位置：`~/.dsh/exam-analyzer/question-bank.json` + `~/.dsh/exam-analyzer/images/*.png`
  （JSON 可备份、可迁移、可直接编辑；删除条目时对应图片一并删除）；
- 同一题重复存入会自动识别，不会产生重复条目；读改写已串行化 + 原子替换，避免并发写坏文件。

### 图形题

分析时**原图与转录文字一起送模型**：转录只用来核对措辞，车标/装置图/几何图一律以图片为准。
（早期版本只送转录文字，导致“四个车标”的题被答成“选项图形缺失，无法确定”。）

### 相似题出图（SVG）

- **原题不重画**：侧栏直接显示框选到的**真实原图**（点击可放大到全屏），避免模型重画走样；
- 相似题若依赖图形，模型会返回 `figure` 字段（内联 SVG），侧边栏渲染成示意图，并标注“仅供理解”；
- SVG 只允许 line/circle/ellipse/rect/polygon/polyline/path/text 等基本图元：
  **服务端**先过滤脚本/外链/`on*` 事件，**客户端**再用 DOMParser 白名单过滤一遍才插入 DOM；
- 提示词要求 SVG 忠实于题干的几何关系（等腰就画等腰、120° 就画钝角、D 在 BC 上不能画出界），
  画不准的复杂图形宁可换成不依赖图形的同类题。

### 数学排版

- **根号**：`√13`、`√(3+√13)` → 带**上横线**的根号（被开方数包进带 `border-top` 的内联块）；
- **分数**：`1/2`、`(3+√13)/2`、`(m²+n²)/(3m−1)` → **上下堆叠 + 分数线**；
- 四位数/年份写法（如 `2026/11`）不会被误判成分数；
- 题干、答案、解析、知识点、相似题、全卷答案统一走这套渲染；**复制出来的仍是纯文本**。

---

## 实现

| 层 | 能力 |
| --- | --- |
| Web `client.js` | 注册进 `shell.overlay`：悬浮入口 + 试卷阅读器。**浏览器端用 pdf.js 逐页渲染**（`vendor/pdf.min.mjs` 由 Host 提供），每页画成 dataURL 交给 `<img>`；框选后本地裁剪再送分析 |
| Host `index.js` | `GET /vendor/pdf.mjs`、`GET /vendor/pdf.worker.mjs` 提供 pdf.js；`POST /analyze`（单题）、`POST /solve-page`（整页答案）、`POST /locate-figure`（存题库前定位图形区域）、`GET/POST /bank/*`（本地题库）；`GET /health`、`GET /model` |
| 模型调用 | 截图经 `attachments.saveImage` 落盘后交给 `llm.stream`；单题分析是「原图 + 转录文字」双输入（图形以图片为准），转录只用来核对措辞 |
| 本地题库 | `~/.dsh/exam-analyzer/question-bank.json` + `images/*.png`；写操作串行化 + 原子替换，删除条目时同步删图 |

## 接口

```text
GET  /api/exam-analyzer/vendor/pdf.mjs         -> pdf.js 主模块
GET  /api/exam-analyzer/vendor/pdf.worker.mjs  -> pdf.js worker
POST /api/exam-analyzer/analyze       {image(dataURL), hint} -> {data:{subject,question,answer,explanation,concepts,related,similar,figure}}
POST /api/exam-analyzer/solve-page    {image(dataURL), page} -> {data:{questions:[{no,stem,answer}]}}
POST /api/exam-analyzer/locate-figure {image(dataURL)}       -> {data:{rects:[{x0,y0,x1,y1}]}}（百分比）
GET  /api/exam-analyzer/bank/list     ?subject=&q=           -> {data:{items,counts,total,path}}
POST /api/exam-analyzer/bank/add      {subject,question,answer,explanation,concepts,similar,images[],source}
POST /api/exam-analyzer/bank/delete   {id}
POST /api/exam-analyzer/bank/update   {id,subject?,note?}
GET  /api/exam-analyzer/bank/image    ?id=&i=                -> 题库里的图形（PNG）
GET  /api/exam-analyzer/health                 -> {ok, route}
GET  /api/exam-analyzer/model                  -> {route, inputModalities, context, reasoning}
```

## 容错

| 步骤 | 推理档位 | 输出上限 | 说明 |
|---|---|---|---|
| ① 截图转录 | `off` | 1200 → 3000 | 只用来核对措辞；不足 15 字视为失败，直接走原图分析 |
| ② 原图 + 文字分析 | `low` | 6000 | 图形题靠原图，转录补文字；相似题可带 SVG 示意图 |
| ②' 精简重试 | `off` | 3200 | 仍被截断时自动降级重跑 |
| ③ 全卷答案 | `off` / `low` | 2400 | 每页一次调用，2200px 高清重渲染 |
| ④ 定位图形 | `low` | 900 | 只返回方位词（top/bottom/left/right/whole） |

解析器会补齐残缺 JSON（补引号/括号、回退到最后一个完整字段）；两次都失败才报错。

## 已知限制

- 页面渲染依赖浏览器 `requestAnimationFrame`：**标签页/窗口最小化时渲染会暂停**，切回前台继续；
  页数上限 40 页，单页按宽度 ≤1400px 渲染（整页识别另按 2200px 重渲染）。
- 框选时把题干连同选项一起框进去，识别最准；框太小会只读到半句话。
- 大页数 PDF 首次导入需逐页渲染（约 1 秒/页），有进度提示。
- 题库里的图形是按模型判断的方位（上/下/左/右/整图）裁出来的，复杂版面可能带一点邻近文字。

## 版本

- 1.2.0 — 学科自适应（数学/物理/化学）、原图与转录双输入（图形题不再瞎猜）、相似题图形用文字描述 + SVG 示意图、本地题库（按学科分类、搜索、原图裁剪入库）、整页答案 2200px 高清、去掉「分段精解」入口
- 1.1.0 — 单页渲染（pdf.js 内置）、面板可缩放、一键全卷答案、根号上横线、分数堆叠、相似题完整选项
- 1.0.0 — 首版（Host 端解析 PDF 位图）
